package com.example.order;

public class Address {
    private String streetName;
    private int houseNumber;
    private String city;
    private String postCode;

    public Address(String streetName, int houseNumber, String city, String postCode) {
    }

    public String getStreetName() {
    }

    public int getHouseNr() {
    }

    public String getCity() {
    }

    public String getPostCode() {
    }

}
