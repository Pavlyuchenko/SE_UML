package com.example.order;

public interface PriceStrategy {

}
