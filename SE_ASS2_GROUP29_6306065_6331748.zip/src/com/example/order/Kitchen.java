package com.example.order;

public class Kitchen {
    private Order[] orders;

    public void addOrder(Order order) {
    }

    public void finishOrder(Order order) {
    }
}
