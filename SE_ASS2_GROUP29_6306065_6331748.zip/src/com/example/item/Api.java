package com.example.item;

import com.example.order.Order;

public class Api {

    public Menu getMenu() {
    }

    public void createOrder(Order order) {
    }
}
