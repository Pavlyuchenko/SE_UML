package com.example.item;

public interface Item extends Price {
    public String getName();

    public String getType();
}