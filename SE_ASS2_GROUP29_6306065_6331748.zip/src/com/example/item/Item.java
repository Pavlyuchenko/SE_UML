/* 
 * GROUP 29
 * Michal Pavlíček, Luuk Dobbelaar
 * i6306065, i6331748
 */
package com.example.item;

public interface Item extends Price {
    public String getName();

    public String getType();
}