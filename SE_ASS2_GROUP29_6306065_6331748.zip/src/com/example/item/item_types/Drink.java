/* 
 * GROUP 29
 * Michal Pavlíček, Luuk Dobbelaar
 * i6306065, i6331748
 */
package com.example.item.item_types;

import com.example.item.Item;
import com.example.item.Price;

public class Drink implements Item {
    private String name;
    private Price price;
    private String type;

    public Drink(String name, String type, double price) {
    }

    @Override
    public String getName() {
    }

    public Double calculatePrice() {
    }

    @Override
    public String getType() {
    }

}
