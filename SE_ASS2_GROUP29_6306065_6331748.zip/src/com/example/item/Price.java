package com.example.item;

public interface Price {
    public double calculatePrice();
}
