/* 
 * GROUP 29
 * Michal Pavlíček, Luuk Dobbelaar
 * i6306065, i6331748
 */
package com.example.item;

public class Ingredient {
    private String name;
    private double amount;
    private String amountUnit;
    private double pricePerUnit;

    public Ingredient(String name, double amount, String amountUnit, double pricePerUnit) {
    }

    public String getName() {
    }

    public double getAmount() {
    }

    public String getAmountUnit() {
    }
}
