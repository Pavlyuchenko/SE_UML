/* 
 * GROUP 29
 * Michal Pavlíček, Luuk Dobbelaar
 * i6306065, i6331748
 */

package com.example.app;

public class App {
    public static void main(String[] args) {

    }
}
