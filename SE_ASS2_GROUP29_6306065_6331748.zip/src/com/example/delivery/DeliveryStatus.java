package com.example.delivery;

public class DeliveryStatus {
    private int status;

    public setStatus(int status) {
    }
}
