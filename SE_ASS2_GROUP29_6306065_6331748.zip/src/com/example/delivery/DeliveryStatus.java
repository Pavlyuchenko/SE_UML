/* 
 * GROUP 29
 * Michal Pavlíček, Luuk Dobbelaar
 * i6306065, i6331748
 */
package com.example.delivery;

public class DeliveryStatus {
    private int status;

    public setStatus(int status) {
    }
}
