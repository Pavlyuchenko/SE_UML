package com.example.delivery;

public class Deliverer {
    private int id;
    private Delivery[] deliveries;
    private boolean free;

    public Deliverer() {
        Delivery delivery = new Delivery(null);
    }

    public void addDelivery(Delivery delivery) {
    }

    public void setFree(boolean free) {
    }
}
