/* 
 * GROUP 29
 * Michal Pavlíček, Luuk Dobbelaar
 * i6306065, i6331748
 */
package com.example.delivery;

public class Deliverer {
    private int id;
    private Delivery[] deliveries;
    private boolean free;

    public Deliverer() {
        Delivery delivery = new Delivery(null);
    }

    public void addDelivery(Delivery delivery) {
    }

    public void setFree(boolean free) {
    }
}
